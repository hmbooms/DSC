Configuration Initialize
{
  param ($MachineName)

  Node $MachineName
  {

    #Install ASP.NET 3.5
    WindowsFeature installdotNet35 
    {             
        Name = "Net-Framework-Core"
        Ensure = "Present"
    }

    #Install ASP.NET 4.6
    WindowsFeature ASP
    {
      Name = "Web-Asp-Net46"
      Ensure = "Present"
      
    }

    #Install the IIS Role
    WindowsFeature IIS
    {
      Name = "Web-Server"
      Ensure = "Present"
      
    }

    WindowsFeature WebHttpRedirect
    {
        Name = "Web-Http-Redirect"
        Ensure = "Present"
    }

    WindowsFeature WebODBCLogging
    {
        Name = "Web-ODBC-Logging "
        Ensure = "Present"
    }

    WindowsFeature WebIPSecurity
    {
        Name = " Web-IP-Security"
        Ensure = "Present"
    }

    WindowsFeature WebNetExt
    {
        Name = "Web-Net-Ext"
        Ensure = "Present"
    }
    
    WindowsFeature WebNetExt46
    {
        Name = "Web-Net-Ext46"
        Ensure = "Present"
    }

    WindowsFeature WebAspNet46
    {
        Name = "Web-Asp-Net46"
        Ensure = "Present"
    }

    WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }

    Package UrlRewrite
    {
        #Install URL Rewrite module for IIS
        DependsOn = "[WindowsFeature]Web-Server"
        Ensure = "Present"
        Name = "IIS URL Rewrite Module 2"
        Path = "http://download.microsoft.com/download/D/D/E/DDE57C26-C62C-4C59-A1BB-31D58B36ADA2/rewrite_amd64_en-US.msi"
        Arguments = '/L*V "C:\WindowsAzure\urlrewriter.txt" /quiet'
        ProductId = "38D32370-3A31-40E9-91D0-D236F47E3C4A"
    }
  }
} 